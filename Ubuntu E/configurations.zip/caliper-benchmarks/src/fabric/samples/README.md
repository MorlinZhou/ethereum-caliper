# Fabric Samples

This folder contains the source chaincode files that are directed to the samples released for the blockchain technologies (Hyperledger Caliper).

## Samples
>Current Hyperledger Caliper samples:

* **fabcar**: requires fabric v1.4.0+
* **marbles**: supported by all fabric versions
* **marbles-norichquery** (a variation of marbles): supported by all fabric versions
