# Contribution Guidelines

Please see our contribution guidelines in [the Solidity documentation](http://solidity.readthedocs.io/en/latest/contributing.html).

Thank you for your help!
