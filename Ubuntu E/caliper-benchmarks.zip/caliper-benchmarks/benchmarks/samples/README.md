# Sample tests

This folder contains tests that are directed to the samples released for the blockchain technologies.