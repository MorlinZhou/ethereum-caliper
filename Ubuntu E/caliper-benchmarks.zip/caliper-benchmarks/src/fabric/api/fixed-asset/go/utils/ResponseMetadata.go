package utils

// ResponseMetadata - manage metadata for query
type ResponseMetadata struct {
	RecordsCount int32
	Bookmark     string
}
