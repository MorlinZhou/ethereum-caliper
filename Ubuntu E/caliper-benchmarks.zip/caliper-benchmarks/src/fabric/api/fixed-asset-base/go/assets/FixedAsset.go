package assets

// FixedAsset - fixed asset
type FixedAsset struct {
	UUID     string
	Creator  string
	Bytesize int
	Content  string
}
